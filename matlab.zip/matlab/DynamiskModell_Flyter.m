%% Konstanter for flyter:
r = 0.125/2; % m
h = 0.44; % m
m_flyter = 5.769; % kg
g = 9.81; % m/s^2
rho_vann = 1000; % kg/m^3
A = pi*r^2; % m^2
c_d = 2.3;
%c_d = 0; % Uten dragkraft
%% Volum av float:
V_flyter = pi*r^2*h; % m^3