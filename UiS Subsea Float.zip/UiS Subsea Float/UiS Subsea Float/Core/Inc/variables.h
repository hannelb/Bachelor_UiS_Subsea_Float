/*
 * variables.h
 *
 *  Created on: Mar 17, 2022
 *      Author: Hanne Lovise Berger
 */

#include "trykksensor.h"
/* ---------------------------------------------------------------------------------------------------------------
 * Endring av modus:
 * Test_Mode = 1; Vil si SW1 & SW2 = Start
 * Test_Mode = 0; Vil si SW2 = Resett, men programkoden venter på magnetfelt.
 *Test_Mode = 2; vil si av og på kontroll med pumpe og ventil. SW2 = ventil, SW1 = Pumpe
 *Test_Mode = 3 HES
 */
uint8_t Test_Mode = 0;


 /* ---------------------------------------------------------------------------------------------------------------
 *	Styrings variabler
 */
uint8_t Start_Sekvens;
uint8_t Pump_Status 		= 0;
uint8_t Valve_Status 		= 0;
uint16_t pump_timer			= 0;
uint16_t valve_timer		= 0;
uint8_t start_trykksensor 	= 0;
uint8_t sekvens_nummer		= 0;
uint8_t antall_like_maalinger = 0;



/*
 * Variabler for sjekk av bryter
 */
uint16_t TickStart;
uint8_t SW1_nettopp_sluppet 	= 0;
uint8_t SW2_nettopp_sluppet 	= 0;
uint8_t gyldig_trykk_SW1		= 0;
uint8_t gyldig_trykk_SW2		= 0;
uint8_t TickTeller 				= 0;

// Variabler for LEDdioder
uint8_t D2;

// Trykk
uint8_t trykkfeil		= 0;
TRYKKSENSOR trykksensor; // Creating the struct
uint32_t P0				= 0;
uint32_t P				= 0;
uint32_t dybde			= 0;
uint32_t bunnTrykk		= 150000; // 1.5 bar
uint32_t nytt_trykk		= 0;
uint32_t forrige_trykk	= 0;
uint32_t differanse_margin = 800; // Differanse mellom to påfølgende trykkmålinger som karakteriseres som samme trykk

// Systick
uint16_t count		= 0;
uint8_t timsek		= 0;

// Sending av data USB
uint8_t dataBuf[10];
uint16_t tid_start		= 0;
uint16_t oppdatert_tid	= 0;
uint16_t logge_tid_ms;
uint16_t logge_tid_sek	= 0;

// ADC
uint16_t magnetsens;
uint16_t magnetsens_skalert;
uint16_t forrige_magnetverdi = 0;
uint16_t ny_magnetverdi		= 0;
uint16_t like_maalinger_magnet = 0;
uint8_t godkjent_magnet = 0;
