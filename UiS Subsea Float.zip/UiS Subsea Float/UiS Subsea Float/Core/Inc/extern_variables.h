/*
 * extern_variables.h
 *
 *  Created on: 28. mar. 2022
 *      Author: Hanne Lovise Berger
 */
// #include "stdbool.h"
#include "stm32f4xx_hal.h"

/* Private globale variabler */
extern uint8_t Pump_Status;
extern uint8_t Valve_Status;
extern uint8_t antall_like_maalinger;
extern uint8_t sekvens_nummer;
extern uint8_t Test_Mode;

// For brytersjekk
extern uint8_t SW1_nettopp_sluppet;
extern uint8_t SW2_nettopp_sluppet;
extern uint8_t gyldig_trykk_SW1;
extern uint8_t gyldig_trykk_SW2;
extern uint8_t TickTeller;

// Bitverdier for LED dioder
extern uint8_t D2;

// Trykk
extern uint8_t trykkfeil;
extern uint8_t status;
extern uint32_t P0;
extern uint32_t P;
extern uint32_t forrige_trykk;
extern uint32_t nytt_trykk;
extern uint32_t differanse_margin;

// Timer systick
extern uint8_t timsek;
extern uint16_t count;
extern uint16_t pump_timer;
extern uint16_t valve_timer;
