/*
 * functions.c
 *
 *  Created on: Mar 17, 2022
 *  Author: Hanne Lovise Berger
 *
 *  Her er alle funksjonene som går på GPIO pinnene, til både trykknapper, LED-dioder, og SSR.
 */
#include "extern_variables.h"
#include "main.h"

/* -----------------------------------------------------------------------------------------------------------
 * Funksjoner for å styre LED diodene.
 -------------------------------------------------------------------------------------------------------------*/
void Set_D2(uint8_t bitstatus){
	if (bitstatus == 1){
		HAL_GPIO_WritePin(D2_GPIO_Port, D2_Pin, GPIO_PIN_SET);
	}
	if (bitstatus == 0){
		HAL_GPIO_WritePin(D2_GPIO_Port, D2_Pin, GPIO_PIN_RESET);
	}
}

void Set_DATA_LED(uint8_t bitstatus){
	if (bitstatus == 1){
		HAL_GPIO_WritePin(DATA_LED_GPIO_Port, DATA_LED_Pin, GPIO_PIN_SET);
	}
	if (bitstatus == 0){
		HAL_GPIO_WritePin(DATA_LED_GPIO_Port, DATA_LED_Pin, GPIO_PIN_RESET);
	}
}

void Set_STAT_LED(uint8_t bitstatus){
	if (bitstatus == 1){
		HAL_GPIO_WritePin(STAT_LED_GPIO_Port, STAT_LED_Pin, GPIO_PIN_SET);
	}
	if (bitstatus == 0){
		HAL_GPIO_WritePin(STAT_LED_GPIO_Port, STAT_LED_Pin, GPIO_PIN_RESET);
	}
}

/* --------------------------------------------------------------------------------------------------------------
 * Funksjoner for å sette SSR til pumpe og ventil.
 ----------------------------------------------------------------------------------------------------------------*/
void Pump_On(void){
	HAL_GPIO_WritePin(SSR_Pump_GPIO_Port, SSR_Pump_Pin, GPIO_PIN_SET);
	Pump_Status = 1;
}

void Pump_Off(void){
	HAL_GPIO_WritePin(SSR_Pump_GPIO_Port, SSR_Pump_Pin, GPIO_PIN_RESET);
	Pump_Status = 0;
}

void Valve_Open(void){
	HAL_GPIO_WritePin(SSR_Valve_GPIO_Port, SSR_Valve_Pin, GPIO_PIN_SET);
	Valve_Status = 1;
}

void Valve_Close(void){
	HAL_GPIO_WritePin(SSR_Valve_GPIO_Port, SSR_Valve_Pin, GPIO_PIN_RESET);
	Valve_Status = 0;
}

/* ----------------------------------------------------------------------------------------------------------------
 * BRYTERAVPRELLING
 ---------------------------------------------------------------------------------------------------------------*/

//void Bryteravprelling(GPIO_Port, GPIO_Pin) {
//
//	if( HAL_GPIO_ReadPin(GPIO_Port, GPIO_Pin) == 0 ) {
//		bryter_nedtrykket = 1;
//		}
//		else {
//			bryter_nedtrykket = 0;
//		}
//
//	if( bryter_nedtrykket ) {
//		bryter_sluppet = 0;
//
//		if(  )
//		}
//}

void Sjekk_SW1(void) {
	if( HAL_GPIO_ReadPin(SW1_GPIO_Port, SW1_Pin) == 0) {
		if(SW1_nettopp_sluppet){

			SW1_nettopp_sluppet = 0;
			gyldig_trykk_SW1 = 1;

			if(Test_Mode == 0){
				sekvens_nummer = 10;
			}
		}
	}
	else {
		SW1_nettopp_sluppet = 1;
	}
}

void Sjekk_SW2(void) {
	if( HAL_GPIO_ReadPin(SW2_GPIO_Port, SW2_Pin) == 0 ) {
		if(SW2_nettopp_sluppet){

			SW2_nettopp_sluppet = 0;
			gyldig_trykk_SW2 = 1;

			if(Test_Mode == 0){
				sekvens_nummer = 10;
			}
		}
	}
	else {
		SW2_nettopp_sluppet = 1;
	}
}

/*------------------------------------------------------------------------------------------------------------
 * DYBDEUTREGNING MED TRYKKSENSOR
------------------------------------------------------------------------------------------------------------ */

void Skal_Flyter_Snu(uint32_t maalt_trykk, uint8_t nytt_sekvens_nummer ){
	int32_t differanse;

	forrige_trykk = nytt_trykk;
	nytt_trykk = maalt_trykk;

	// Når differanse i nåtrykk og forrigetrykk <= 400: antall like målinger ++
	differanse = nytt_trykk - forrige_trykk;
	if(differanse < 0){
		differanse = -differanse;
	}

	if(differanse <= differanse_margin ){
		antall_like_maalinger ++;
		if(antall_like_maalinger == 100){
			antall_like_maalinger = 0;
			sekvens_nummer = nytt_sekvens_nummer;
		}
	}
	else{
		antall_like_maalinger = 0;
	}
}

/*-----------------------------------------------------------------------------------------------------------
 * MÅLING AV MAGNETFELT
 ----------------------------------------------------------------------------------------------------------*/
uint16_t MAGNETSENSOR_LesVerdi(ADC_HandleTypeDef *hadc1){
	uint16_t raaverdi;

	HAL_ADC_Start(hadc1);
//	HAL_ADC_PollForConversion(hadc1, HAL_MAX_DELAY);
	raaverdi = HAL_ADC_GetValue(hadc1);
	return raaverdi;
}

//void Detektert_Magnetfelt(uint16_t raaverdi, uint8_t nytt_sekvens_nummer){
//
//	int16_t differanse;
//
//	forrige_magnet_verdi = ny_magnet_verdi;
//	ny_verdi = raaverdi;
//
//	differanse = ny_magnet_verdi - forrige_magnet_verdi;
//	if(differanse < 0){
//		differanse = -differanse;
//	}
//
//	if(differanse <= differanse_margin ){
//		antall_like_maalinger ++;
//		if(antall_like_maalinger == 30){
//			antall_like_maalinger = 0;
//			sekvens_nummer = nytt_sekvens_nummer;
//		}
//	}
//	else{
//		antall_like_maalinger = 0;
//	}
//
//}

uint16_t MAGNETSENSOR_SkalerVerdi(uint16_t raaverdi){
	uint16_t skalertverdi;

	skalertverdi = 0.8*raaverdi;

	return skalertverdi;
}







